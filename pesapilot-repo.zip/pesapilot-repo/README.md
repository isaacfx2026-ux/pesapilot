# PESAPILOT

An AI-assisted budget manager built as a final-year project at Kabarak University.

PESAPILOT lets a user record income and expenses, get a category suggested from the description, set monthly limits per category, see a financial overview, spot unusual spending, view a next-month forecast and read plain-language recommendations.

## Run it

Open `index.html` in any browser. There is nothing to install.

## Features

- Sign up and sign in, with a separate set of records per account
- Add, edit and delete transactions in a searchable, sortable log
- Category suggestions from the transaction description (TF-IDF with class centroids)
- Unusual-transaction flags: more than the category mean plus two standard deviations
- Monthly forecast by linear regression, shown only with at least three months of history
- Budget limits with progress bars and alerts
- Monthly and per-category reports, with CSV copy and download
- AI advisor on the Forecast screen (see below)

## AI advisor

In this standalone copy, paste your own Anthropic API key on the Forecast screen. It is kept in your browser only and sent only to Anthropic. Do not put a key in a public deployment. A shared deployment needs a backend that holds the key.

## Data

Records are saved in the browser (localStorage). Clearing site data removes them.

## Notes

All figures in the example account are sample data. Forecasts and recommendations are estimates, not financial advice.
